marker_list = []


def vision_marker(index):
  vm5_seen = False

  if index == 11:
    chassis_ctrl.rotate_with_degree(rm_define.anticlockwise, 179)

  elif index == 12:
    robotic_arm_ctrl.recenter()
    robotic_arm_ctrl.moveto(210, 0)
    chassis_ctrl.move_with_distance(0, 1)

  elif index == 13:
    chassis_ctrl.rotate_with_degree(rm_define.anticlockwise, 90)

  elif index == 14:
    chassis_ctrl.rotate_with_degree(rm_define.anticlockwise, 90)
    while not vm5_seen:
      chassis_ctrl.move_with_time(0, 1)
      if marker_list[1] == 15:
        vm5_seen = True
        chassis_ctrl.stop()

  elif index == 15:
    for i in range(12):
      chassis_ctrl.move_with_distance(0, 0.05)
      chassis.ctrl.rotate_with_degree(rm_define.clockwise, 15)

  elif index == 8:
    chassis_ctrl.rotate_with_degree(rm_define.anticlockwise, 90)
    gripper_ctrl.open()


def safety():  #prevent robot from bumping into wall
  if ir_distance_sensor_ctrl.get_distance_info(1) < 20:
    chassis_ctrl.stop()
  while ir_distance_sensor_ctrl.get_distance_info(1) < 20:
    chassis_ctrl.rotate_with_degree(rm_define.clockwise, 5)


def start():  #main

  chassis_ctrl.set_trans_speed(1)
  chassis_ctrl.set_rotate_speed(10)
  vision_ctrl.enable_detection(rm_define.vision_detection_marker)
  vision_ctrl.set_marker_detection_distance(0.5)
  media_ctrl.exposure_value_update(rm_define.exposure_value_large)
  ir_distance_sensor_ctrl.enable_measure(1)
  gripper_ctrl.open()

  time.sleep(2)

  while True:  # make robot keep looking for markers
    if len(marker_list) > 1:
      time.sleep(2)
      marker_list = vision_ctrl.get_marker_detection_info()
      index = marker_list[1]
      vision_marker(index)
      marker_list = []